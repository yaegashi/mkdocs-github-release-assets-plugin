# mkdocs-github-release-assets-plugin

MkDocs plugin to include GitHub release assets in the document.
